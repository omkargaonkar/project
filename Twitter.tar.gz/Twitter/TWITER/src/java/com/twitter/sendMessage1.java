/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.twitter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author admin
 */
public class sendMessage1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            PrintWriter out = response.getWriter();
            ArrayList add=new ArrayList();
                  try
                  {
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/twitter", "root", "root");
                                PreparedStatement stmt2 = con.prepareStatement("SELECT * from user");
                               
                                 ResultSet rs1=stmt2.executeQuery();
                                 String number=request.getParameter("number");
                                 String message1=request.getParameter("message");
                                  while(rs1.next())
                                  {
                               
         // int mobile1=Integer.parseInt(number);
                
                                   add.add(rs1.getString(5));
          
        
                                      
                                      
                                      
                                      
                                      
                                  }
                                  
                                  
                                    StringBuilder commaSepValueBuilder = new StringBuilder();
 
    //Looping through the list
    for ( int i = 0; i< add.size(); i++){
      //append the value into the builder
      commaSepValueBuilder.append(add.get(i));
       
      //if the value is not the last element of the list
      //then append the comma(,) as well
      if ( i != add.size()-1){
        commaSepValueBuilder.append(", ");
      }
    }
    System.out.println(commaSepValueBuilder.toString());
            
                                  
                                   String url="http://login.wishbysms.com/api/sendhttp.php?authkey=63479ALNFUic3cO5358be93&";
            String message="message=this is admin:"+message1;
            String mobile="mobiles="+commaSepValueBuilder;                              
            
            String route="route=2";
            String senderid="sender=ACCEDE"; 
            String finaluri=url+mobile+"&"+message+"&"+senderid+"&"+route;      
        response.sendRedirect(finaluri); 
            
          
                  }
                  catch(Exception e)
                  {
                      e.printStackTrace();
                  }
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
