/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.twitter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author accede6
 */
public class Admin_message extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String count=request.getParameter("count");
            String firsttime=request.getParameter("firsttime");
            String location=request.getParameter("location");
            String admin_status=request.getParameter("message");// variable for storing in WQ history table
            String msg=request.getParameter("message");
            
            Calendar calendar = new GregorianCalendar();
            System.out.println("Current Date::");
            SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
            String date = sdf.format(calendar.getTime());
            System.out.println("current date"+date);
           try
           {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("Jdbc:mysql://localhost/twitter", "root", "root");
            
            PreparedStatement ps1=con.prepareStatement("insert into admin_message values(?,?,?)");
             
            ps1.setInt(1, 0);
            ps1.setString(2, msg);
            ps1.setString(3,date);
            int z=ps1.executeUpdate();
           
            ///////updating in history table
            /////////////////data for storing in history table
            
            System.out.println("location"+location);
            System.out.println("time"+firsttime);
            System.out.println("count"+count);
            
            PreparedStatement history=con.prepareStatement("insert into eq_history values(?,?,?,?,?)");
            history.setInt(1, 0);
            history.setString(2, admin_status);
            history.setString(3,location);
            history.setString(4,firsttime);
            history.setString(5,count);
              int y=history.executeUpdate();
            /////////////////data for storing in history table close
              if(z>0)
              {
                  
                   PreparedStatement ps2=con.prepareStatement("select * from admin_message where msg_content='"+msg+"'");
                    ResultSet rs1=ps2.executeQuery();
                     
                    if(rs1.next())
                    {
                     int msg_id=rs1.getInt(1);//retrived msg id
                     
                       PreparedStatement ps3=con.prepareStatement("select * from user");// retrived user id
                       ResultSet rs3=ps3.executeQuery();
                         int s=0;
                        while(rs3.next())
                        {
                            
                            int uid=rs3.getInt(1);// retrived msg id
                            System.out.println("--------------data at inserting point of user message-----");
                             System.out.println("message_id"+msg_id);
                             System.out.println("message_id"+uid);
                             System.out.println("delivery time"+date);
                             
                            
                            
                            
                             PreparedStatement ps4=con.prepareStatement("insert into user_message values(?,?,?,?,?)");// retrived user id
                             ps4.setInt(1, 0);
                             ps4.setInt(2, uid);
                             ps4.setInt(3, msg_id);
                             ps4.setString(4, date);
                             ps4.setInt(5, 0);
                            s=ps4.executeUpdate();
                             if(s>0)
                             {
                               System.out.println("saved to user message");   
                             }
                             else
                             {
                               System.out.println("error in saving user message");   
                             }
                            
                        }
                         
                      
                    }
                   
                   
                 System.out.println("message saved");
                 response.sendRedirect("admin_message.jsp");
              }
              else
              {
                   System.out.println("message not saved saved");
                    response.sendRedirect("Admin_home.jsp");
              }
            
            
            
            
            
           }
           catch(Exception e)
           {
               e.printStackTrace();
           }
           
        
        
        
        
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
