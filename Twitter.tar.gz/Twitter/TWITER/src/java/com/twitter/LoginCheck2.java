/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.twitter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Pratiksha
 */
public class LoginCheck2 extends HttpServlet { 

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
       response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String username= request.getParameter("UserName");
            String password=request.getParameter("Password");  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/twitter", "root", "root");
            PreparedStatement ps=con.prepareStatement("select * from user where username=? and password=?");
            ps.setString(1, username);
            ps.setString(2, password);     
            ResultSet rs=ps.executeQuery();    
           if(rs.next()){
           String abcd=rs.getString("username");     
         HttpSession xt=request.getSession();  
           int abc=rs.getInt("id");
           xt.setAttribute("id",abc);
           xt.setAttribute("username", abcd);     
            String mobileno= rs.getString("mobileno");
            Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost/twitter", "root", "root");
          PreparedStatement ps2=con2.prepareStatement("update user set flag=1 where id=?");  
          ps2.setInt(1, abc);
          
         int check= ps2.executeUpdate();
          if(check>0){
          
           Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/sns", "root", "root");
          PreparedStatement ps1=con1.prepareStatement("update globalidlist set flag=1 where sns='twitter' and mobileno=?");
          ps1.setString(1,mobileno);
             int i=ps1.executeUpdate();
           
          if(i>0){
           RequestDispatcher rd=request.getRequestDispatcher("HomePage.jsp");           
           rd.forward(request, response);
        }else{
           RequestDispatcher rd=request.getRequestDispatcher("HomePage.jsp");         
           rd.forward(request, response);     
          
              
          }}
            }
            else{
                request.setAttribute("pass","Wrongpass");        
                out.println("Wrong Password");                                   
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginCheck2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginCheck2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginCheck2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginCheck2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
