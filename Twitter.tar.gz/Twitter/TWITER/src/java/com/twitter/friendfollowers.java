/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.twitter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Accede
 */
public class friendfollowers extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        
          HttpSession xt=request.getSession();
          response.setContentType("text/html;charset=UTF-8");
          int followerid=Integer.parseInt(request.getParameter("followerid"));
           String id1= xt.getAttribute("id").toString();
          int id2=Integer.parseInt(id1);
          //////////////////////date 
             Calendar calendar = new GregorianCalendar();
            System.out.println("Current Date::");
            SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
            String date = sdf.format(calendar.getTime());
            System.out.println("current date"+date);
          
          
          
          
          /////////////////////close of date
        try (PrintWriter out = response.getWriter()) {
           
              System.out.println(followerid);
           
           
            
             System.out.println(id2);
          xt.setAttribute("id2",id2);
       
           Class.forName("com.mysql.jdbc.Driver");
          Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/twitter", "root", "root");
          PreparedStatement stmt1=con.prepareStatement("select * from getfollowers where (id=? and follwerid=?) and (follwerid=? and id=?)");
          stmt1.setInt(1, followerid);
          stmt1.setInt(2,id2);
           stmt1.setInt(3, followerid);
          stmt1.setInt(4,id2);
          ResultSet rs5=stmt1.executeQuery();
          System.out.println("selected from  getfollowers ");
          if(!rs5.next()){
                 
               
         PreparedStatement stmt = con.prepareStatement("insert into getfollowers(id,follwerid,notif_time,notif_status) values(?,?,?,?)");
        
         stmt.setInt(1, id2);
         stmt.setInt(2, followerid); 
         stmt.setString(3, date); 
         stmt.setInt(4, 0); 
         int i=stmt.executeUpdate();   
         System.out.println("insert into getfollowers ");
         PreparedStatement stmt7 = con.prepareStatement("select max(id1) from getfollowers");
                ResultSet rs10=stmt7.executeQuery();
                int count=0; 
                while(rs10.next())
                 {
                 count =rs10.getInt(1);
                 } 
                 System.out.println("total count into getfollowers "+count);
         if(i>0){
              
               PreparedStatement stmt11 = con.prepareStatement("insert into notification values(?,?,?,?)");
                 stmt11.setInt(1, 0);
                 stmt11.setInt(2, count);
                 stmt11.setString(3, date);   
                  stmt11.setInt(4, 0);   
                 int z=stmt11.executeUpdate();   
                
                if(z>0)
                {
                    RequestDispatcher rd=request.getRequestDispatcher("HomePage.jsp");
                    rd.forward(request, response);
                }
                else
                {
                    System.out.println("no notification set");
                    RequestDispatcher rd=request.getRequestDispatcher("HomePage.jsp");
                    rd.forward(request, response);
                    
                }
             
             
         
         }
        }
          else{
              out.println("You are already following your friend");
          }
        
        }
            
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(friendfollowers.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(friendfollowers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(friendfollowers.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(friendfollowers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
