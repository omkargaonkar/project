/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.twitter;

//import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Accede
 */
public class Update extends HttpServlet {

    private Object k;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            HttpSession xt = request.getSession();
            String username = xt.getAttribute("username").toString();
           
            System.out.println("check point 1");
            String abcd = request.getParameter("statusupdate");
            System.out.println(abcd);

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/twitter", "root", "root");
            PreparedStatement stmt = con.prepareStatement("select * from user where username=?");
            stmt.setString(1,username);
            ResultSet rs = stmt.executeQuery();
             Date date = new Date();
             
             
              Calendar calendar = Calendar.getInstance();
          java.sql.Date statusDate = new java.sql.Date(calendar.getTime().getTime());
            System.out.println("post date=>"+statusDate);
          String sdate=statusDate.toString();
          //////////////////////system data
             
          
           SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
           String date2 = sdf.format(calendar.getTime());
          
          
          
          
          //////////////////////close of system date   
           
           ///////checking for abuse words 
           String abus = abcd.toLowerCase();
                Boolean found1;

                found1 = abus.contains("shit")|| abus.contains("piss")||abus.contains("fuck")||abus.contains("cunt")||abus.contains("cocksucker")||abus.contains("motherfucker")||abus.contains("tits")||abus.contains("boobs")||abus.contains("sex");
                
                              
                System.out.println(found1);
               //checaking for abuse words
                if (found1) {
                           
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('YOU CANT POST ABUSE CONTENT OVER SITE');");
                            out.println("location=HomePage.jsp");
                            out.println("</script>");
                            //response.sendRedirect("HomePage.jsp");                           
                           
                           System.out.println("abus found");
                           }
                 else
                {
           //////////////////////////////////
            if(rs.next()) {

                int i = rs.getInt(1);
                System.out.println(i);
                PreparedStatement ps1 = con.prepareStatement("insert into statusupdate values(?,?,?,?)");
                ps1.setInt(1, 0);
                ps1.setString(2, abcd);
                ps1.setInt(3, i);
                ps1.setString(4,date2);
                int i1 = ps1.executeUpdate();
                if (i1 > 0) {

                    RequestDispatcher rd = request.getRequestDispatcher("HomePage.jsp");
                    rd.forward(request, response);
                }
           

                String k = abcd.toLowerCase();
                Boolean found;

                found = k.contains("earthquake at") || k.contains("its shaking in")||k.contains("earthquake hits")||k.contains("going to happen")||k.contains("an earthquake last night")||k.contains("Earthquakes may occur at any moment")||
                        k.contains("We have a lot of earthquakes in")||k.contains("Everybody in the building felt the earthquake")||k.contains("felt the earthquake")||k.contains("houses were damaged in the earthquake")||
                        k.contains("biggest one that we had ever experienced")||k.contains("shook the houses")||k.contains("earthquake can happen at any time")||k.contains("There was an earthquake yesterday")||
                        k.contains("house collapsed in an earthquake")||k.contains("earthquake this morning")||k.contains("There was a big earthquake last night")||k.contains("impossible to predict earthquakes"); 
                                
                System.out.println(found);

                if (found) {
                    String query1 = "insert into witheq values(?,?,?,?,?)";
                    PreparedStatement stmt2 = con.prepareStatement(query1);
                    stmt2.setInt(1, 0);
                    stmt2.setString(2, abcd);
                    stmt2.setInt(3, i);
                    stmt2.setString(4, date2);
                    stmt2.setInt(5, 0);
                    int ik1 = stmt2.executeUpdate();
                    PreparedStatement stmt1 = con.prepareStatement("select * from witheq where eq_status=0");

                    ResultSet rs1 = stmt1.executeQuery();

                    int rowCount = 0;

                    while (rs1.next()) {
                        // Process the row.
                        rowCount++;
                    }
                    System.out.println("---witheq tweets---"+rowCount);
                    xt.setAttribute("rowCount",rowCount);
                    ////////////////////////////seting attribute for count of earthquick/////////
                    HttpSession session2=request.getSession();
                    session2.setAttribute("total_witheq", rowCount);
                    
                    PreparedStatement stmt8 = con.prepareStatement("select * from withouteq where with_eq_status=0");

                ResultSet rs8 = stmt8.executeQuery();

                int rowCount3 = 0;

                while (rs8.next()) {
                    // Process the row.
                    rowCount3++;
                }
                System.out.println("-- withouteq tweets ---" + rowCount3);
                /////////////////////////first time/////////////////////
                
                
                
                //////////////////////close of first time//////////////
                xt.setAttribute("rowCount3", rowCount3);
                ////////////////////////////seting attribute for count of with_out_earthquick/////////
                    HttpSession session3=request.getSession();
                    session3.setAttribute("total_without_eq", rowCount3);
                
                
                
                int total=rowCount+rowCount3;
                
                    
                    float pa1=(float)rowCount/total;
                    float pa2=1-pa1;
                    
                    System.out.println("--probability of witheq pa1----"+pa1);
                    System.out.println("--probability of withouteq pa2----"+pa2);
                    xt.setAttribute("pa1",pa1);
                     xt.setAttribute("pa2",pa2);

                } else {
                    String query2 = "insert into withouteq values(?,?,?,?,?)";
                    PreparedStatement stmt3 = con.prepareStatement(query2);
                    stmt3.setInt(1, 0);
                    stmt3.setString(2, abcd);
                    stmt3.setInt(3, i);
                    stmt3.setString(4, date2);
                    stmt3.setInt(5, 0);
                    
                    int i2 = stmt3.executeUpdate();

                    PreparedStatement stmt5 = con.prepareStatement("select * from withouteq");

                    ResultSet rs5 = stmt5.executeQuery();

                    int rowCount1 = 0;

                    while (rs5.next()) {
                        // Process the row.
                        rowCount1++;
                    }
                    System.out.println("--withouteq tweets---" + rowCount1);
                    xt.setAttribute("rowCount1", rowCount1);
                    
                     PreparedStatement stmt8 = con.prepareStatement("select * from witheq");

                ResultSet rs8 = stmt8.executeQuery();

                int rowCount10 = 0;

                while (rs8.next()) {
                    // Process the row.
                    rowCount10++;
                }
                System.out.println("-- witheq ---" + rowCount10);
                xt.setAttribute("rowCount3", rowCount10);
                
                int total=rowCount1+rowCount10;
                
                }//close of abuse function 
                
                
//                    
//                    float pa2=(float)rowCount1/total;
//                    System.out.println("--probability of withouteq pa2----"+pa2);
//                    xt.setAttribute("pa2",pa2);
//                    
                    
                    
//                    float pa2=(float)rowCount1/rowCount3;
//                    System.out.println("--probability of withouteq----"+pa2);
//                    xt.setAttribute("pa2",pa2);

                }

            }

        }
    }
// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Update.class
                    .getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Update.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Update.class
                    .getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Update.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
