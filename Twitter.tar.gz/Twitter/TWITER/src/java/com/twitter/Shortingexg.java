/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.twitter;

import java.util.*;

/**
 *
 * @author accede6
 */
public class Shortingexg {
    
      public static void main(String args[])
      {
         
           Integer a[]=new Integer[05];
            
           System.out.println("START ENTERING DATA FOR SORTING ");
              
           Scanner sc=new Scanner(System.in);
           int y=0;
            for(int i=0;i<5;i++)
            {
             a[i]=sc.nextInt();  
            }
           
            System.out.println("wait for sorting");
             for(int i=0;i<5;i++)
             {
                 System.out.println("before sorted order"+a[i]);
             }
            int temp=0;
            for(int i=0;i<5;i++)
            {
                for(int j=0;j<5;j++)
                {
                   while(a[i]<a[j+1])
                    {
                        temp = a[j];
                        a[j] = a[i];
                        a[i] = temp;
                    }

                }
                
            }
            for(int i=0;i<5;i++)
             {
                 System.out.println("sorted order"+a[i]);
             }
            
      }
    
}
