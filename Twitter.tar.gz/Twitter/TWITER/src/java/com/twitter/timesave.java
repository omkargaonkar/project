
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;



import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Accede
 */
public class timesave
{
    
     public static void main(String args[]) throws ParseException
     {
      Date date = new Date();
      System.out.println("first date"+date);
      
      DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	   //get current date time with Date()
	    String date2=dateFormat.format(date);
            String date3=dateFormat.format(date);
	   System.out.println("Secound date"+date2);
 
	   //get current date time with Calendar()
	   Calendar cal = Calendar.getInstance();
	   System.out.println(dateFormat.format(cal.getTime())); 
           
           
           
           
            DateFormat format = new SimpleDateFormat("HH:mm:ss");
             String r=format.format(new Date());
              
           System.out.println("new TIME"+r);
           
           
             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");      
               Date dateWithoutTime = sdf.parse(sdf.format(new Date()));
              System.out.println("date with new 1"+dateWithoutTime);
           
              
              Date date1 = new Date();
              String modifiedDate= new SimpleDateFormat("yyyy/MM/dd").format(date1);
           System.out.println("modified date only"+modifiedDate);
          /////////////////////new content /////////////////
           System.out.println("-------------START-------------------");
       Calendar calendar = new GregorianCalendar();
      System.out.println("Current Date::");
      SimpleDateFormat sdf2015 = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
      String date2015 = sdf2015.format(calendar.getTime());
      System.out.println("current date"+date2015);

      //Subtract 4 months,5 days,12 hours and 24 minutes
      calendar.add(Calendar.MONTH, -0);
      calendar.add(Calendar.DAY_OF_MONTH, -0);
      calendar.add(Calendar.HOUR, -00);
      calendar.add(Calendar.MINUTE, -05);
      System.out.println("After subtracting 4 months,5 days,12 hours and 24 minutes::");
      date2015 = sdf2015.format(calendar.getTime());
      System.out.println(date);
           
          System.out.println("-------------Sclose-------------------");  
           //////////////////////////new content close //////////
           
           try
           {
               Class.forName("com.mysql.jdbc.Driver");
               Connection con=DriverManager.getConnection("Jdbc:mysql://localhost/amol", "root", "root");
              
               String sql1="insert into timesave(time) values('"+date2+"')";
                
               Statement smt1=con.createStatement();
               int z=smt1.executeUpdate(sql1);
               
                if(z>=1)
                {
                    System.out.println("saved");
                }
               else
                {
                    System.out.println("not saved");
                }
               
                
                String sql2="select * from timesave where time<'"+date2+"'";
                Statement smt2=con.createStatement(); 
                  ResultSet rs=smt2.executeQuery(sql2);
                    while(rs.next())
                    {
                      String s=rs.getString(2);
                      System.out.println("retriving date "+s);
                    }
                
               
           }
           catch(Exception e)
           {
               e.printStackTrace();
           }
           
           
           
           
     }
}
	