/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Accede
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class date3 {
   /**
    * main class
    * @param args
    */
   public static void main(String[] args) {
      date3 calUsage = new date3();
      calUsage.subtractTime();
   }
   private void subtractTime() {
      //set calendar to 6th March 2009
      Calendar calendar = new GregorianCalendar();
      System.out.println("Current Date::");
      SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
      String date = sdf.format(calendar.getTime());
      System.out.println("current date"+date);

      //Subtract 4 months,5 days,12 hours and 24 minutes
      calendar.add(Calendar.MONTH, -0);
      calendar.add(Calendar.DAY_OF_MONTH, -0);
      calendar.add(Calendar.HOUR, -00);
      calendar.add(Calendar.MINUTE, -05);
      System.out.println("After subtracting 4 months,5 days,12 hours and 24 minutes::");
      date = sdf.format(calendar.getTime());
      System.out.println(date);
   }
}