/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.demo;

import java.util.Map;

/**
 *
 * @author accede6
 */
public class sendKeyValue {
      public static Object getKeyFromValue(Map hm, Object value) 
      {
          for (Object o : hm.keySet()) 
          {
               if (hm.get(o).equals(value)) 
                   {
                  return o;
                     }
          }
            return null;
      }
                                                            
    
}
