/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author accede
 */
public class SendMail  {
public static void main(String[] args) {  
   
            String to="pssakharkar@gmail.com";
         
             // Sender's email ID needs to be mentioned
      String from = "accedesolutions4343@gmail.com";//change accordingly
      final String username = "accedesolutions4343";//change accordingly
      final String password = "accede@12345";//change accordingly
        String host = "smtp.gmail.com";    
            /*
           
            Properties props = new Properties();  
             System.out.println("message sent successfully00");
            props.put("mail.smtp.user", "accedeprojects@gmail.com");
            props.put("mail.smtp.host", "smtp.gmail.com");  
            props.put("mail.smtp.port", "465"); 
            props.put("mail.smtp.socketFactory.port", "465");  
            props.put("mail.smtp.socketFactory.class",  
                      "javax.net.ssl.SSLSocketFactory");  
            props.put("mail.smtp.auth", "true");  */
      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
             

       Session session = Session.getInstance(props,
      new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
         }
      });

        try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         message.setRecipients(Message.RecipientType.TO,
         InternetAddress.parse(to));

         // Set Subject: header field
         message.setSubject("Testing Subject");

         // Now set the actual message
         message.setText("Hello, this is sample for to check send "
            + "email using JavaMailAPI ");

         // Send message
         Transport.send(message);

         System.out.println("Sent message successfully....");

      } catch (MessagingException e)
      {
            throw new RuntimeException(e);
      }
   }
}

            
            
            
            
            
           
    

    

