-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.20


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema twitter
--

CREATE DATABASE IF NOT EXISTS twitter;
USE twitter;

--
-- Definition of table `twitter`.`admin`
--

DROP TABLE IF EXISTS `twitter`.`admin`;
CREATE TABLE  `twitter`.`admin` (
  `admin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `twitter`.`admin` (`admin_id`,`username`,`password`) VALUES 
 (1,'admin','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `twitter`.`admin_message`
--

DROP TABLE IF EXISTS `twitter`.`admin_message`;
CREATE TABLE  `twitter`.`admin_message` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_content` varchar(5000) NOT NULL,
  `msg_time` varchar(45) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`admin_message`
--

/*!40000 ALTER TABLE `admin_message` DISABLE KEYS */;
INSERT INTO `twitter`.`admin_message` (`msg_id`,`msg_content`,`msg_time`) VALUES 
 (1,'sadsadsad','24 Feb 2015 06:14 PM'),
 (2,'hi its earthquake in goa ','24 Feb 2015 06:15 PM'),
 (3,'new message','24 Feb 2015 06:16 PM'),
 (4,'new msg ','25 Feb 2015 10:10 AM'),
 (5,'hi its amol','25 Feb 2015 10:13 AM'),
 (6,'new msg 10:17 am','25 Feb 2015 10:17 AM'),
 (7,'its again new msg form admin','25 Feb 2015 10:18 AM'),
 (8,'new altered msg ','25 Feb 2015 10:27 AM'),
 (9,'new mesage ','25 Feb 2015 10:55 AM'),
 (10,'third messagfe ','25 Feb 2015 10:56 AM'),
 (11,'hi its new mesagfe ','25 Feb 2015 10:57 AM'),
 (12,'again its new message ','25 Feb 2015 11:51 AM'),
 (13,'new messgae','25 Feb 2015 03:47 PM'),
 (14,'hi its going to earthquick ','25 Feb 2015 06:26 PM'),
 (15,'its testing message','3 Mar 2015 06:30 AM');
/*!40000 ALTER TABLE `admin_message` ENABLE KEYS */;


--
-- Definition of table `twitter`.`getfollowers`
--

DROP TABLE IF EXISTS `twitter`.`getfollowers`;
CREATE TABLE  `twitter`.`getfollowers` (
  `id1` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) DEFAULT NULL,
  `follwerid` int(11) DEFAULT NULL,
  `notif_time` varchar(45) NOT NULL,
  `notif_status` int(10) unsigned NOT NULL,
  `timestamp` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id1`),
  KEY `id` (`id`),
  CONSTRAINT `getfollowers_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`getfollowers`
--

/*!40000 ALTER TABLE `getfollowers` DISABLE KEYS */;
INSERT INTO `twitter`.`getfollowers` (`id1`,`id`,`follwerid`,`notif_time`,`notif_status`,`timestamp`,`status`) VALUES 
 (50,68,69,'12 Mar 2015 05:26 PM',1,'Mon Jan 04 10:42:20 IST 2016',NULL),
 (51,69,68,'12 Mar 2015 05:41 PM',1,'Tue Dec 29 17:17:20 IST 2015',NULL),
 (52,70,68,'3 Oct 2015 01:19 AM',1,NULL,NULL),
 (53,68,70,'3 Oct 2015 01:20 AM',0,'Mon Jan 04 10:42:20 IST 2016',NULL),
 (54,68,70,'3 Oct 2015 01:22 AM',0,'Mon Jan 04 10:42:20 IST 2016',NULL),
 (55,68,70,'3 Oct 2015 01:28 AM',0,'Mon Jan 04 10:42:20 IST 2016',NULL),
 (56,68,70,'3 Oct 2015 01:28 AM',0,'Mon Jan 04 10:42:20 IST 2016',NULL),
 (57,68,70,'3 Oct 2015 01:28 AM',0,'Mon Jan 04 10:42:20 IST 2016',NULL);
/*!40000 ALTER TABLE `getfollowers` ENABLE KEYS */;


--
-- Definition of table `twitter`.`notification`
--

DROP TABLE IF EXISTS `twitter`.`notification`;
CREATE TABLE  `twitter`.`notification` (
  `notification_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `get_follow_id` int(10) unsigned NOT NULL,
  `notif_time` varchar(45) NOT NULL,
  `notf_status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`notification`
--

/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `twitter`.`notification` (`notification_id`,`get_follow_id`,`notif_time`,`notf_status`) VALUES 
 (1,31,'25 Feb 2015 02:50 PM',0),
 (2,32,'25 Feb 2015 03:45 PM',0),
 (3,34,'25 Feb 2015 05:23 PM',0),
 (4,35,'25 Feb 2015 05:24 PM',0),
 (5,36,'25 Feb 2015 05:27 PM',0),
 (6,37,'25 Feb 2015 05:27 PM',0),
 (7,38,'25 Feb 2015 05:30 PM',0),
 (8,39,'25 Feb 2015 05:36 PM',0),
 (9,40,'25 Feb 2015 05:36 PM',0),
 (10,41,'25 Feb 2015 05:39 PM',0),
 (11,42,'25 Feb 2015 05:41 PM',0),
 (12,43,'25 Feb 2015 05:44 PM',0),
 (13,44,'25 Feb 2015 05:46 PM',0),
 (14,45,'25 Feb 2015 05:52 PM',0),
 (15,46,'25 Feb 2015 06:25 PM',0),
 (16,47,'9 Mar 2015 04:35 PM',0),
 (17,48,'12 Mar 2015 02:25 PM',0),
 (18,49,'12 Mar 2015 02:25 PM',0),
 (19,50,'12 Mar 2015 05:26 PM',0),
 (20,51,'12 Mar 2015 05:41 PM',0),
 (21,52,'3 Oct 2015 01:19 AM',0),
 (22,53,'3 Oct 2015 01:20 AM',0),
 (23,54,'3 Oct 2015 01:22 AM',0),
 (24,55,'3 Oct 2015 01:28 AM',0),
 (25,56,'3 Oct 2015 01:28 AM',0),
 (26,57,'3 Oct 2015 01:28 AM',0);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;


--
-- Definition of table `twitter`.`states`
--

DROP TABLE IF EXISTS `twitter`.`states`;
CREATE TABLE  `twitter`.`states` (
  `s_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_name` varchar(45) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`states`
--

/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `twitter`.`states` (`s_id`,`s_name`) VALUES 
 (1,'pune '),
 (2,'goa'),
 (3,'punjab'),
 (4,'agra'),
 (5,'delhi'),
 (6,'j&k'),
 (7,'assam'),
 (8,'jabalpur'),
 (9,'Mp'),
 (10,'up'),
 (11,'ladak');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;


--
-- Definition of table `twitter`.`statusupdate`
--

DROP TABLE IF EXISTS `twitter`.`statusupdate`;
CREATE TABLE  `twitter`.`statusupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(1000) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `status_time` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_statusupdate_1` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`statusupdate`
--

/*!40000 ALTER TABLE `statusupdate` DISABLE KEYS */;
INSERT INTO `twitter`.`statusupdate` (`id`,`status`,`userid`,`status_time`) VALUES 
 (47,'                                           \r\n     check it\r\n                       ',68,'12 Mar 2015 02:04 PM'),
 (48,'    yeahhhhhhhhhh                                       \r\n                            ',68,'12 Mar 2015 02:06 PM'),
 (49,'                                           \r\n  check it now\r\n                          ',69,'12 Mar 2015 02:30 PM'),
 (50,'                                           \r\n   check it out\r\n                         ',68,'19 Mar 2015 12:52 PM'),
 (51,'                                           \r\n          1231221                  ',68,'25 Mar 2015 12:02 PM'),
 (52,'                                           \r\n                            hey',70,'3 Oct 2015 01:27 AM'),
 (53,'                                           \r\n         Check it out\r\n                   ',68,'27 Oct 2015 11:33 AM'),
 (54,'                                           \r\n          yeah                  ',68,'27 Oct 2015 11:33 AM'),
 (55,'wegewgeew\r\n                            ',68,'19 Dec 2015 12:44 PM');
INSERT INTO `twitter`.`statusupdate` (`id`,`status`,`userid`,`status_time`) VALUES 
 (56,'                                           \r\n 7iyuiiyu                           ',68,'2 Jan 2016 05:55 PM'),
 (57,'tyootyityi                                           \r\n                            ',68,'2 Jan 2016 05:55 PM');
/*!40000 ALTER TABLE `statusupdate` ENABLE KEYS */;


--
-- Definition of table `twitter`.`totator`
--

DROP TABLE IF EXISTS `twitter`.`totator`;
CREATE TABLE  `twitter`.`totator` (
  `torator_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`torator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`totator`
--

/*!40000 ALTER TABLE `totator` DISABLE KEYS */;
/*!40000 ALTER TABLE `totator` ENABLE KEYS */;


--
-- Definition of table `twitter`.`user`
--

DROP TABLE IF EXISTS `twitter`.`user`;
CREATE TABLE  `twitter`.`user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `DOB` varchar(50) DEFAULT NULL,
  `mobileno` varchar(50) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `flag` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `twitter`.`user` (`id`,`firstname`,`lastname`,`DOB`,`mobileno`,`emailid`,`address`,`username`,`password`,`flag`) VALUES 
 (68,'Pravin','Sakharkar','03/08/1990','9763635024','pssakharkar@gmail.com','pune','pss','pss','0'),
 (69,'rahul','bhide','03/08/1990','9876543211','rahul@gmail.com','pune','rahul','rahul','0'),
 (70,'pss1','pss1','10/12/1995','9890251212','gggg@gmail.com','pune','pss1','pss12345','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `twitter`.`user_message`
--

DROP TABLE IF EXISTS `twitter`.`user_message`;
CREATE TABLE  `twitter`.`user_message` (
  `U_msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `U_M_user_id` int(10) unsigned NOT NULL,
  `A_msg_id` int(10) unsigned NOT NULL,
  `Msg_time` varchar(45) NOT NULL,
  `msg_status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`U_msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`user_message`
--

/*!40000 ALTER TABLE `user_message` DISABLE KEYS */;
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (1,6,43,'25 Feb 2015 10:17 AM',0),
 (2,6,44,'25 Feb 2015 10:17 AM',0),
 (3,6,45,'25 Feb 2015 10:17 AM',0),
 (4,6,46,'25 Feb 2015 10:17 AM',0),
 (5,6,48,'25 Feb 2015 10:17 AM',0),
 (6,6,49,'25 Feb 2015 10:17 AM',0),
 (7,6,50,'25 Feb 2015 10:17 AM',0),
 (8,6,51,'25 Feb 2015 10:17 AM',0),
 (9,6,52,'25 Feb 2015 10:17 AM',0),
 (10,6,53,'25 Feb 2015 10:17 AM',0),
 (11,6,54,'25 Feb 2015 10:17 AM',0),
 (12,6,55,'25 Feb 2015 10:17 AM',0),
 (13,6,56,'25 Feb 2015 10:17 AM',0),
 (14,6,57,'25 Feb 2015 10:17 AM',0),
 (15,6,58,'25 Feb 2015 10:17 AM',0),
 (16,6,59,'25 Feb 2015 10:17 AM',0),
 (17,6,60,'25 Feb 2015 10:17 AM',0),
 (18,6,61,'25 Feb 2015 10:17 AM',0),
 (19,6,62,'25 Feb 2015 10:17 AM',0),
 (20,6,63,'25 Feb 2015 10:17 AM',0),
 (21,6,64,'25 Feb 2015 10:17 AM',0),
 (22,6,65,'25 Feb 2015 10:17 AM',0),
 (23,7,43,'25 Feb 2015 10:18 AM',0),
 (24,7,44,'25 Feb 2015 10:18 AM',0),
 (25,7,45,'25 Feb 2015 10:18 AM',0),
 (26,7,46,'25 Feb 2015 10:18 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (27,7,48,'25 Feb 2015 10:18 AM',0),
 (28,7,49,'25 Feb 2015 10:18 AM',0),
 (29,7,50,'25 Feb 2015 10:18 AM',0),
 (30,7,51,'25 Feb 2015 10:18 AM',0),
 (31,7,52,'25 Feb 2015 10:18 AM',0),
 (32,7,53,'25 Feb 2015 10:18 AM',0),
 (33,7,54,'25 Feb 2015 10:18 AM',0),
 (34,7,55,'25 Feb 2015 10:18 AM',0),
 (35,7,56,'25 Feb 2015 10:18 AM',0),
 (36,7,57,'25 Feb 2015 10:18 AM',0),
 (37,7,58,'25 Feb 2015 10:18 AM',0),
 (38,7,59,'25 Feb 2015 10:18 AM',0),
 (39,7,60,'25 Feb 2015 10:18 AM',0),
 (40,7,61,'25 Feb 2015 10:18 AM',0),
 (41,7,62,'25 Feb 2015 10:18 AM',0),
 (42,7,63,'25 Feb 2015 10:18 AM',0),
 (43,7,64,'25 Feb 2015 10:18 AM',0),
 (44,7,65,'25 Feb 2015 10:18 AM',0),
 (45,43,8,'25 Feb 2015 10:27 AM',1),
 (46,44,8,'25 Feb 2015 10:27 AM',1),
 (47,45,8,'25 Feb 2015 10:27 AM',0),
 (48,46,8,'25 Feb 2015 10:27 AM',1),
 (49,48,8,'25 Feb 2015 10:27 AM',0),
 (50,49,8,'25 Feb 2015 10:27 AM',0),
 (51,50,8,'25 Feb 2015 10:27 AM',0),
 (52,51,8,'25 Feb 2015 10:27 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (53,52,8,'25 Feb 2015 10:27 AM',0),
 (54,53,8,'25 Feb 2015 10:27 AM',0),
 (55,54,8,'25 Feb 2015 10:27 AM',0),
 (56,55,8,'25 Feb 2015 10:27 AM',0),
 (57,56,8,'25 Feb 2015 10:27 AM',0),
 (58,57,8,'25 Feb 2015 10:27 AM',0),
 (59,58,8,'25 Feb 2015 10:27 AM',0),
 (60,59,8,'25 Feb 2015 10:27 AM',0),
 (61,60,8,'25 Feb 2015 10:27 AM',0),
 (62,61,8,'25 Feb 2015 10:27 AM',0),
 (63,62,8,'25 Feb 2015 10:27 AM',0),
 (64,63,8,'25 Feb 2015 10:27 AM',0),
 (65,64,8,'25 Feb 2015 10:27 AM',0),
 (66,65,8,'25 Feb 2015 10:27 AM',0),
 (67,43,9,'25 Feb 2015 10:55 AM',1),
 (68,44,9,'25 Feb 2015 10:55 AM',0),
 (69,45,9,'25 Feb 2015 10:55 AM',0),
 (70,46,9,'25 Feb 2015 10:55 AM',1),
 (71,48,9,'25 Feb 2015 10:55 AM',0),
 (72,49,9,'25 Feb 2015 10:55 AM',0),
 (73,50,9,'25 Feb 2015 10:55 AM',0),
 (74,51,9,'25 Feb 2015 10:55 AM',0),
 (75,52,9,'25 Feb 2015 10:55 AM',0),
 (76,53,9,'25 Feb 2015 10:55 AM',0),
 (77,54,9,'25 Feb 2015 10:55 AM',0),
 (78,55,9,'25 Feb 2015 10:55 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (79,56,9,'25 Feb 2015 10:55 AM',0),
 (80,57,9,'25 Feb 2015 10:55 AM',0),
 (81,58,9,'25 Feb 2015 10:55 AM',0),
 (82,59,9,'25 Feb 2015 10:55 AM',0),
 (83,60,9,'25 Feb 2015 10:55 AM',0),
 (84,61,9,'25 Feb 2015 10:55 AM',0),
 (85,62,9,'25 Feb 2015 10:55 AM',0),
 (86,63,9,'25 Feb 2015 10:55 AM',0),
 (87,64,9,'25 Feb 2015 10:55 AM',0),
 (88,65,9,'25 Feb 2015 10:55 AM',0),
 (89,43,10,'25 Feb 2015 10:56 AM',1),
 (90,44,10,'25 Feb 2015 10:56 AM',0),
 (91,45,10,'25 Feb 2015 10:56 AM',0),
 (92,46,10,'25 Feb 2015 10:56 AM',0),
 (93,48,10,'25 Feb 2015 10:56 AM',0),
 (94,49,10,'25 Feb 2015 10:56 AM',0),
 (95,50,10,'25 Feb 2015 10:56 AM',0),
 (96,51,10,'25 Feb 2015 10:56 AM',0),
 (97,52,10,'25 Feb 2015 10:56 AM',0),
 (98,53,10,'25 Feb 2015 10:56 AM',0),
 (99,54,10,'25 Feb 2015 10:56 AM',0),
 (100,55,10,'25 Feb 2015 10:56 AM',0),
 (101,56,10,'25 Feb 2015 10:56 AM',0),
 (102,57,10,'25 Feb 2015 10:56 AM',0),
 (103,58,10,'25 Feb 2015 10:56 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (104,59,10,'25 Feb 2015 10:56 AM',0),
 (105,60,10,'25 Feb 2015 10:56 AM',0),
 (106,61,10,'25 Feb 2015 10:56 AM',0),
 (107,62,10,'25 Feb 2015 10:56 AM',0),
 (108,63,10,'25 Feb 2015 10:56 AM',0),
 (109,64,10,'25 Feb 2015 10:56 AM',0),
 (110,65,10,'25 Feb 2015 10:56 AM',0),
 (111,43,11,'25 Feb 2015 10:57 AM',1),
 (112,44,11,'25 Feb 2015 10:57 AM',0),
 (113,45,11,'25 Feb 2015 10:57 AM',0),
 (114,46,11,'25 Feb 2015 10:57 AM',0),
 (115,48,11,'25 Feb 2015 10:57 AM',0),
 (116,49,11,'25 Feb 2015 10:57 AM',0),
 (117,50,11,'25 Feb 2015 10:57 AM',0),
 (118,51,11,'25 Feb 2015 10:57 AM',0),
 (119,52,11,'25 Feb 2015 10:57 AM',0),
 (120,53,11,'25 Feb 2015 10:57 AM',0),
 (121,54,11,'25 Feb 2015 10:57 AM',0),
 (122,55,11,'25 Feb 2015 10:57 AM',0),
 (123,56,11,'25 Feb 2015 10:57 AM',0),
 (124,57,11,'25 Feb 2015 10:57 AM',0),
 (125,58,11,'25 Feb 2015 10:57 AM',0),
 (126,59,11,'25 Feb 2015 10:57 AM',0),
 (127,60,11,'25 Feb 2015 10:57 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (128,61,11,'25 Feb 2015 10:57 AM',0),
 (129,62,11,'25 Feb 2015 10:57 AM',0),
 (130,63,11,'25 Feb 2015 10:57 AM',0),
 (131,64,11,'25 Feb 2015 10:57 AM',0),
 (132,65,11,'25 Feb 2015 10:57 AM',0),
 (133,43,12,'25 Feb 2015 11:51 AM',1),
 (134,44,12,'25 Feb 2015 11:51 AM',0),
 (135,45,12,'25 Feb 2015 11:51 AM',0),
 (136,46,12,'25 Feb 2015 11:51 AM',0),
 (137,48,12,'25 Feb 2015 11:51 AM',0),
 (138,49,12,'25 Feb 2015 11:51 AM',0),
 (139,50,12,'25 Feb 2015 11:51 AM',0),
 (140,51,12,'25 Feb 2015 11:51 AM',0),
 (141,52,12,'25 Feb 2015 11:51 AM',0),
 (142,53,12,'25 Feb 2015 11:51 AM',0),
 (143,54,12,'25 Feb 2015 11:51 AM',0),
 (144,55,12,'25 Feb 2015 11:51 AM',0),
 (145,56,12,'25 Feb 2015 11:51 AM',0),
 (146,57,12,'25 Feb 2015 11:51 AM',0),
 (147,58,12,'25 Feb 2015 11:51 AM',0),
 (148,59,12,'25 Feb 2015 11:51 AM',0),
 (149,60,12,'25 Feb 2015 11:51 AM',0),
 (150,61,12,'25 Feb 2015 11:51 AM',0),
 (151,62,12,'25 Feb 2015 11:51 AM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (152,63,12,'25 Feb 2015 11:51 AM',0),
 (153,64,12,'25 Feb 2015 11:51 AM',0),
 (154,65,12,'25 Feb 2015 11:51 AM',0),
 (155,43,13,'25 Feb 2015 03:47 PM',1),
 (156,44,13,'25 Feb 2015 03:47 PM',0),
 (157,45,13,'25 Feb 2015 03:47 PM',0),
 (158,46,13,'25 Feb 2015 03:47 PM',0),
 (159,48,13,'25 Feb 2015 03:47 PM',0),
 (160,49,13,'25 Feb 2015 03:47 PM',0),
 (161,50,13,'25 Feb 2015 03:47 PM',0),
 (162,51,13,'25 Feb 2015 03:47 PM',0),
 (163,52,13,'25 Feb 2015 03:47 PM',0),
 (164,53,13,'25 Feb 2015 03:47 PM',0),
 (165,54,13,'25 Feb 2015 03:47 PM',0),
 (166,55,13,'25 Feb 2015 03:47 PM',0),
 (167,56,13,'25 Feb 2015 03:47 PM',0),
 (168,57,13,'25 Feb 2015 03:47 PM',0),
 (169,58,13,'25 Feb 2015 03:47 PM',0),
 (170,59,13,'25 Feb 2015 03:47 PM',0),
 (171,60,13,'25 Feb 2015 03:47 PM',0),
 (172,61,13,'25 Feb 2015 03:47 PM',0),
 (173,62,13,'25 Feb 2015 03:47 PM',0),
 (174,63,13,'25 Feb 2015 03:47 PM',0),
 (175,64,13,'25 Feb 2015 03:47 PM',0);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (176,65,13,'25 Feb 2015 03:47 PM',0),
 (177,43,14,'25 Feb 2015 06:26 PM',1),
 (178,44,14,'25 Feb 2015 06:26 PM',1),
 (179,45,14,'25 Feb 2015 06:26 PM',0),
 (180,46,14,'25 Feb 2015 06:26 PM',0),
 (181,48,14,'25 Feb 2015 06:26 PM',0),
 (182,49,14,'25 Feb 2015 06:26 PM',0),
 (183,50,14,'25 Feb 2015 06:26 PM',0),
 (184,51,14,'25 Feb 2015 06:26 PM',0),
 (185,52,14,'25 Feb 2015 06:26 PM',0),
 (186,53,14,'25 Feb 2015 06:26 PM',0),
 (187,54,14,'25 Feb 2015 06:26 PM',0),
 (188,55,14,'25 Feb 2015 06:26 PM',0),
 (189,56,14,'25 Feb 2015 06:26 PM',0),
 (190,57,14,'25 Feb 2015 06:26 PM',0),
 (191,58,14,'25 Feb 2015 06:26 PM',0),
 (192,59,14,'25 Feb 2015 06:26 PM',0),
 (193,60,14,'25 Feb 2015 06:26 PM',0),
 (194,61,14,'25 Feb 2015 06:26 PM',0),
 (195,62,14,'25 Feb 2015 06:26 PM',0),
 (196,63,14,'25 Feb 2015 06:26 PM',0),
 (197,64,14,'25 Feb 2015 06:26 PM',0),
 (198,65,14,'25 Feb 2015 06:26 PM',0),
 (199,66,14,'25 Feb 2015 06:26 PM',1);
INSERT INTO `twitter`.`user_message` (`U_msg_id`,`U_M_user_id`,`A_msg_id`,`Msg_time`,`msg_status`) VALUES 
 (200,43,15,'3 Mar 2015 06:30 AM',0),
 (201,44,15,'3 Mar 2015 06:30 AM',0),
 (202,45,15,'3 Mar 2015 06:30 AM',0),
 (203,46,15,'3 Mar 2015 06:30 AM',0),
 (204,66,15,'3 Mar 2015 06:30 AM',0);
/*!40000 ALTER TABLE `user_message` ENABLE KEYS */;


--
-- Definition of table `twitter`.`userimages`
--

DROP TABLE IF EXISTS `twitter`.`userimages`;
CREATE TABLE  `twitter`.`userimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(500) DEFAULT NULL,
  `fileName` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`userimages`
--

/*!40000 ALTER TABLE `userimages` DISABLE KEYS */;
INSERT INTO `twitter`.`userimages` (`id`,`userid`,`fileName`) VALUES 
 (9,'69','Lighthouse.jpg'),
 (12,'68','Tulips.jpg');
/*!40000 ALTER TABLE `userimages` ENABLE KEYS */;


--
-- Definition of table `twitter`.`users`
--

DROP TABLE IF EXISTS `twitter`.`users`;
CREATE TABLE  `twitter`.`users` (
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Definition of table `twitter`.`witheq`
--

DROP TABLE IF EXISTS `twitter`.`witheq`;
CREATE TABLE  `twitter`.`witheq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alerteq` varchar(5000) DEFAULT NULL,
  `userid` int(10) unsigned NOT NULL,
  `eq_time` varchar(45) NOT NULL,
  `eq_status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`witheq`
--

/*!40000 ALTER TABLE `witheq` DISABLE KEYS */;
INSERT INTO `twitter`.`witheq` (`id`,`alerteq`,`userid`,`eq_time`,`eq_status`) VALUES 
 (21,'its shaking in pune                   ',46,'26 Feb 2015 11:42 AM',0),
 (22,'hello its going to happen earthquick soon  in  goa',43,'26 Feb 2015 12:04 PM',0),
 (23,'pune ',46,'28 Feb 2015 11:46 AM',0),
 (24,'pune ',43,'28 Feb 2015 11:46 AM',0),
 (25,'delhi',43,'28 Feb 2015 11:46 AM',0);
/*!40000 ALTER TABLE `witheq` ENABLE KEYS */;


--
-- Definition of table `twitter`.`withouteq`
--

DROP TABLE IF EXISTS `twitter`.`withouteq`;
CREATE TABLE  `twitter`.`withouteq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `normal` varchar(5000) NOT NULL,
  `userid` int(10) unsigned NOT NULL,
  `witheq_time` varchar(45) NOT NULL,
  `with_eq_status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter`.`withouteq`
--

/*!40000 ALTER TABLE `withouteq` DISABLE KEYS */;
INSERT INTO `twitter`.`withouteq` (`id`,`normal`,`userid`,`witheq_time`,`with_eq_status`) VALUES 
 (69,'hello buddys its shaking over hear in canada                   ',44,'26 Feb 2015 11:38 AM',0),
 (70,'its shaking over canada         ',46,'26 Feb 2015 11:42 AM',0),
 (71,'new message                  ',43,'26 Feb 2015 12:23 PM',0),
 (72,'new post form user1            ',43,'26 Feb 2015 12:48 PM',0),
 (73,'hi                     ',46,'4 Mar 2015 05:53 AM',0),
 (74,'check it out\r\n                                           \r\n                            ',67,'9 Mar 2015 04:35 PM',0),
 (75,' itw working\r\n                                          \r\n                            ',67,'9 Mar 2015 04:35 PM',0),
 (76,'                                           \r\n     check it\r\n                       ',68,'12 Mar 2015 02:04 PM',0),
 (77,'    yeahhhhhhhhhh                                       \r\n                            ',68,'12 Mar 2015 02:06 PM',0),
 (78,'                                           \r\n  check it now\r\n                          ',69,'12 Mar 2015 02:30 PM',0),
 (79,'                                           \r\n   check it out\r\n                         ',68,'19 Mar 2015 12:52 PM',0);
INSERT INTO `twitter`.`withouteq` (`id`,`normal`,`userid`,`witheq_time`,`with_eq_status`) VALUES 
 (80,'                                           \r\n          1231221                  ',68,'25 Mar 2015 12:02 PM',0),
 (81,'                                           \r\n                            hey',70,'3 Oct 2015 01:27 AM',0),
 (82,'                                           \r\n         Check it out\r\n                   ',68,'27 Oct 2015 11:33 AM',0),
 (83,'                                           \r\n          yeah                  ',68,'27 Oct 2015 11:33 AM',0),
 (84,'wegewgeew\r\n                            ',68,'19 Dec 2015 12:44 PM',0),
 (85,'                                           \r\n 7iyuiiyu                           ',68,'2 Jan 2016 05:55 PM',0),
 (86,'tyootyityi                                           \r\n                            ',68,'2 Jan 2016 05:55 PM',0);
/*!40000 ALTER TABLE `withouteq` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
