
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accountdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountname` varchar(500) DEFAULT NULL,
  `username` varchar(500) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `mobileno` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accountdetails` WRITE;
/*!40000 ALTER TABLE `accountdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountdetails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromu` varchar(100) DEFAULT NULL,
  `tou` varchar(500) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  `time` varchar(500) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (12,'9763635024','9876543211','rgvrjwe alnd','2/8/15 12:40 PM',NULL),(13,'9763635024','9876543211','egrbk kfb','2/8/15 12:40 PM',NULL),(14,'9763635024','9876543211','egrbk kfb','2/8/15 12:41 PM',NULL),(15,'9876543211','9763635024','checking it now','2/8/15 12:41 PM',NULL),(16,'9763635024','9876543211','rgjkre egnlreg','2/8/15 12:42 PM',NULL),(17,'9876543211','pssakharkar@gmail.com','hey rahul','2/16/15 5:13 PM',NULL),(18,'9876543211','pssakharkar@gmail.com','Now I think its working','2/17/15 10:42 AM',NULL),(19,'9763635024','rahul@gmail.com','check it now','2/17/15 10:43 AM',NULL),(20,'9876543211','pssakharkar@gmail.com','yeah','2/17/15 10:43 AM',NULL),(21,'9876543211','9763635024','hey dude','2/21/15 10:29 AM',NULL),(22,'9876543211','9763635024','hey dude','2/21/15 10:29 AM',NULL),(23,'9876543211','9763635024','check it','2/21/15 5:12 PM','unread'),(24,'9876543211','9763635024','check it','2/21/15 5:12 PM','unread'),(25,'9876543211','pssakharkar@gmail.com','frhjtrh','3/19/15 11:32 AM','unread'),(26,'9763635024','9876543211','hey rahul','3/20/15 6:00 PM','unread'),(27,'9763635024','rahul@gmail.com','check it out','3/20/15 6:01 PM','unread'),(28,'9763635024','9876543211','checking it again','3/24/15 4:50 PM','unread'),(29,'9763635024','9876543211','yea itw working fine','3/24/15 4:50 PM','unread'),(30,'9763635024','9876543211','yea itw working fine','3/24/15 4:50 PM','unread'),(31,'9763635024','rahul@gmail.com','lets do it','4/6/15 10:51 AM','unread');
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `globalidlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalidlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `sns` varchar(50) DEFAULT NULL,
  `mobileno` varchar(50) DEFAULT NULL,
  `flag` int(11) DEFAULT NULL,
  `peeronline` int(11) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `globalidlist` WRITE;
/*!40000 ALTER TABLE `globalidlist` DISABLE KEYS */;
INSERT INTO `globalidlist` VALUES (139,'Rahul','abcde','abcde','facebook','9876543211',1,1,'rahul','on'),(140,'Rahul','abcde','abcde','gmail','9876543211',1,1,'rahul','on'),(141,'Rahul','abcde','abcde','twitter','9876543211',1,1,'rahul','on'),(142,'Pravin','Sakharkar','abcde','facebook','9763635024',1,1,'pss','on'),(143,'Pravin','Sakharkar','abcde','gmail','9763635024',1,1,'pss','on'),(144,'Pravin','Sakharkar','abcde','twitter','9763635024',1,1,'pss','on'),(145,'prakash','sharma','abcde','facebook','9876543215',1,0,'prakash',NULL),(146,'vaishnav','surwase','abcde','facebook','9876543219',1,0,'vaish',NULL),(183,'Ganesh','Tambile','abcde','facebook','8149365076',1,1,'ganesh',NULL);
/*!40000 ALTER TABLE `globalidlist` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipaddress` (
  `ipaddress` varchar(500) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ipaddress` WRITE;
/*!40000 ALTER TABLE `ipaddress` DISABLE KEYS */;
INSERT INTO `ipaddress` VALUES ('192.168.1.4',1);
/*!40000 ALTER TABLE `ipaddress` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `otp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(500) DEFAULT NULL,
  `key1` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `otp` WRITE;
/*!40000 ALTER TABLE `otp` DISABLE KEYS */;
INSERT INTO `otp` VALUES (1,'9763635024',925584219),(2,'8149365076',7308),(3,'9876543211',153789864);
/*!40000 ALTER TABLE `otp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `userimages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(500) DEFAULT NULL,
  `fileName` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `userimages` WRITE;
/*!40000 ALTER TABLE `userimages` DISABLE KEYS */;
INSERT INTO `userimages` VALUES (10,'68','Penguins.jpg'),(11,'9876543219','Penguins.jpg'),(12,'9876543211','Penguins.jpg'),(13,'9763635024','Penguins.jpg');
/*!40000 ALTER TABLE `userimages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

