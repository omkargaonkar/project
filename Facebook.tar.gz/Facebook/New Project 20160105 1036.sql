-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.20


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema osn
--

CREATE DATABASE IF NOT EXISTS osn;
USE osn;

--
-- Definition of table `osn`.`blacklist`
--

DROP TABLE IF EXISTS `osn`.`blacklist`;
CREATE TABLE  `osn`.`blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blacklistuid` int(11) DEFAULT NULL,
  `blacklistedby` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`blacklist`
--

/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;


--
-- Definition of table `osn`.`chat`
--

DROP TABLE IF EXISTS `osn`.`chat`;
CREATE TABLE  `osn`.`chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromu` varchar(500) DEFAULT NULL,
  `tou` varchar(500) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `date` varchar(1000) DEFAULT NULL,
  `fromname` varchar(500) DEFAULT NULL,
  `flag` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`chat`
--

/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;


--
-- Definition of table `osn`.`comment`
--

DROP TABLE IF EXISTS `osn`.`comment`;
CREATE TABLE  `osn`.`comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(1000) DEFAULT NULL,
  `comment_by` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`comment`
--

/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;


--
-- Definition of table `osn`.`friend_request`
--

DROP TABLE IF EXISTS `osn`.`friend_request`;
CREATE TABLE  `osn`.`friend_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromuser` varchar(1000) DEFAULT NULL,
  `touser` varchar(1000) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`friend_request`
--

/*!40000 ALTER TABLE `friend_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `friend_request` ENABLE KEYS */;


--
-- Definition of table `osn`.`friendrequest`
--

DROP TABLE IF EXISTS `osn`.`friendrequest`;
CREATE TABLE  `osn`.`friendrequest` (
  `touser` varchar(100) DEFAULT NULL,
  `fromuser` varchar(1000) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `relation` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`friendrequest`
--

/*!40000 ALTER TABLE `friendrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `friendrequest` ENABLE KEYS */;


--
-- Definition of table `osn`.`friends`
--

DROP TABLE IF EXISTS `osn`.`friends`;
CREATE TABLE  `osn`.`friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `friendid` int(11) DEFAULT NULL,
  `tvalue` double DEFAULT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`friends`
--

/*!40000 ALTER TABLE `friends` DISABLE KEYS */;
INSERT INTO `osn`.`friends` (`id`,`userid`,`friendid`,`tvalue`,`time`) VALUES 
 (95,39,38,0,'Mon Jan 04 10:42:20 IST 2016'),
 (96,38,39,0,'Mon Jan 04 10:42:20 IST 2016'),
 (97,38,40,0,'Mon Jan 04 10:42:20 IST 2016'),
 (98,40,38,0,'Mon Jan 04 10:42:20 IST 2016');
/*!40000 ALTER TABLE `friends` ENABLE KEYS */;


--
-- Definition of table `osn`.`images`
--

DROP TABLE IF EXISTS `osn`.`images`;
CREATE TABLE  `osn`.`images` (
  `name` varchar(100) DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `file` blob,
  `time` varchar(100) DEFAULT NULL,
  `tags` varchar(1000) DEFAULT NULL,
  `Users` varchar(1000) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `Racess` varchar(100) DEFAULT NULL,
  `groups` varchar(1000) DEFAULT NULL,
  `Gacess` varchar(100) DEFAULT NULL,
  `meter` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`images`
--

/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;


--
-- Definition of table `osn`.`keywords`
--

DROP TABLE IF EXISTS `osn`.`keywords`;
CREATE TABLE  `osn`.`keywords` (
  `m_keywords` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`keywords`
--

/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;


--
-- Definition of table `osn`.`notification`
--

DROP TABLE IF EXISTS `osn`.`notification`;
CREATE TABLE  `osn`.`notification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notification` varchar(100) NOT NULL,
  `userid` varchar(45) NOT NULL,
  `fromid` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`notification`
--

/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `osn`.`notification` (`id`,`notification`,`userid`,`fromid`) VALUES 
 (7,' You recived a request!!','rahul@gmail.com','pss@gmail.com'),
 (8,' You recived a request!!','pss@gmail.com','akshay@gmail.com');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;


--
-- Definition of table `osn`.`profile`
--

DROP TABLE IF EXISTS `osn`.`profile`;
CREATE TABLE  `osn`.`profile` (
  `firstname` varchar(45) NOT NULL,
  `filename` varchar(45) NOT NULL,
  PRIMARY KEY (`firstname`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`profile`
--

/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;


--
-- Definition of table `osn`.`status_update`
--

DROP TABLE IF EXISTS `osn`.`status_update`;
CREATE TABLE  `osn`.`status_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `status` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`status_update`
--

/*!40000 ALTER TABLE `status_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `status_update` ENABLE KEYS */;


--
-- Definition of table `osn`.`user`
--

DROP TABLE IF EXISTS `osn`.`user`;
CREATE TABLE  `osn`.`user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `DOB` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `flag` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `osn`.`user` (`id`,`firstname`,`lastname`,`DOB`,`gender`,`mobileno`,`emailid`,`username`,`password`,`flag`) VALUES 
 (38,'pravin','sakharkar','03/08/1990','male','9763635024','pss@gmail.com','pss','pss',0),
 (39,'rahul','abcde','03/08/1990','male','9876543211','rahul@gmail.com','rahul','rahul',0),
 (40,'akshay','abcde','03/08/1990','male','8793238010','akshay@gmail.com','akshay','akshay',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `osn`.`userimages`
--

DROP TABLE IF EXISTS `osn`.`userimages`;
CREATE TABLE  `osn`.`userimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(500) DEFAULT NULL,
  `imagepath` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`userimages`
--

/*!40000 ALTER TABLE `userimages` DISABLE KEYS */;
INSERT INTO `osn`.`userimages` (`id`,`userid`,`imagepath`) VALUES 
 (33,'38','Penguins.jpg');
/*!40000 ALTER TABLE `userimages` ENABLE KEYS */;


--
-- Definition of table `osn`.`users`
--

DROP TABLE IF EXISTS `osn`.`users`;
CREATE TABLE  `osn`.`users` (
  `name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pnum` varchar(50) DEFAULT NULL,
  `home` varchar(100) DEFAULT NULL,
  `school` varchar(100) DEFAULT NULL,
  `college` varchar(100) DEFAULT NULL,
  `employee` varchar(100) DEFAULT NULL,
  `privacy` varchar(100) DEFAULT NULL,
  `profilepic` blob,
  `friends` varchar(1000) DEFAULT NULL,
  `family` varchar(1000) DEFAULT NULL,
  `friend` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Definition of table `osn`.`wall`
--

DROP TABLE IF EXISTS `osn`.`wall`;
CREATE TABLE  `osn`.`wall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statusupdate` varchar(1000) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `wallflag` tinyint(1) NOT NULL,
  `friendid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn`.`wall`
--

/*!40000 ALTER TABLE `wall` DISABLE KEYS */;
INSERT INTO `osn`.`wall` (`id`,`statusupdate`,`userid`,`wallflag`,`friendid`) VALUES 
 (195,'Chrysanthemum.jpg',38,0,38);
/*!40000 ALTER TABLE `wall` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
