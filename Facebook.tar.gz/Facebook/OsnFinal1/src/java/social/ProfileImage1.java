/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package social;

import com.util.DbConnection;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileUploadException;


/**
 *
 * @author admin
 */
public class ProfileImage1 extends HttpServlet {

     private File tmpDir;
    private static final String DESTINATION_DIR_PATH = "file";
    private File destinationDir;
private static final long serialVersionUID = 1L;

    private static final String DATA_DIRECTORY = "data";
    private static final int MAX_MEMORY_SIZE = 1024 * 1024 * 5;
    private static final int MAX_REQUEST_SIZE = 1024 * 1024*3;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
         System.out.print("checking innnnnnn");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            // Check that we have a file upload request
        boolean isMultipart = org.apache.commons.fileupload.servlet.ServletFileUpload.isMultipartContent(request);

        if (!isMultipart) {
            return;
        }
        HttpSession ss=request.getSession();
        String userid=ss.getAttribute("id").toString();   
          Connection con=DbConnection.getfcConection();
        // Create a factory for disk-based file items
        org.apache.commons.fileupload.disk.DiskFileItemFactory factory = new org.apache.commons.fileupload.disk.DiskFileItemFactory();

        // Sets the size threshold beyond which files are written directly to
        // disk.
        factory.setSizeThreshold(MAX_MEMORY_SIZE);

        // Sets the directory used to temporarily store files that are larger
        // than the configured size threshold. We use temporary directory for
        // java
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        // constructs the folder where uploaded file will be stored
        String uploadFolder = getServletContext().getRealPath("");
             //  + File.separator + DATA_DIRECTORY;         
        // Create a new file upload handler
        org.apache.commons.fileupload.servlet.ServletFileUpload upload = new org.apache.commons.fileupload.servlet.ServletFileUpload(factory);
            System.out.println("skhgksjhgkjshgkhksgks"+upload);
        // Set overall request size constraint
        upload.setSizeMax(MAX_REQUEST_SIZE);
        
        try {  
            // Parse the request
          //  LSBAlgorithm a=new LSBAlgorithm();
         
            List items = upload.parseRequest( request);     
            Iterator iter = items.iterator();
            while (iter.hasNext()) {
                org.apache.commons.fileupload.FileItem item = (org.apache.commons.fileupload.FileItem) iter.next();   
                int i1=0;
                if (!item.isFormField()) {
                    
                      
                BufferedImage rd= ImageIO.read(item.getInputStream());
                 
                 
                 // BufferedImage output= steg.steg("AABBCCDD", rd);
             
       //  ImageIO.write(output, "png", new File("D://stego//StegoImage4.bmp"));
                 
             
                 
               //BufferedImage output=  FStego.write(rd, "lets check this now");
                // ImageIO.write(output, "jpeg", new File("D://stego//StegoImage1.bmp"));
              //  String check2= FStego.read(rd);
                 
                 
                 
                    String fileName = new File(item.getName()).getName();
                    String x=request.getSession().getAttribute("id").toString();
                    int i=Integer.parseInt(x);
                    String filePath = uploadFolder +"/wallimages/"+ fileName;   
                    PreparedStatement ps3=con.prepareStatement("insert into wall values(?,?,?,?,?)");
                    ps3.setInt(1, 0);
                    ps3.setString(2,fileName);
                    ps3.setInt(3,i);
                    ps3.setInt(4, 0);
                    ps3.setInt(5, i);   
                    
                   i1=ps3.executeUpdate();
               PreparedStatement ps1=con.prepareStatement("select * from friends where userid=?");
                ps1.setInt(1, i);
                ResultSet rs1= ps1.executeQuery();
                while(rs1.next()){
                int j=rs1.getInt(3);
                
                
                    PreparedStatement ps=con.prepareStatement("insert into wall values(?,?,?,?,?)");
                    ps.setInt(1, 0);
                    ps.setString(2,fileName);
                    ps.setInt(3,i);
                    ps.setInt(4, 0);
                    ps.setInt(5, j);
                    
                   i1=ps.executeUpdate();
                }
                    
                    if(i1>0){
                    File uploadedFile = new File(filePath); 
                    System.out.println(filePath);
                    // saves the file to upload directory
                    item.write(uploadedFile);}
                    
                    RequestDispatcher rdd=request.getRequestDispatcher("Home.jsp");
                    rdd.forward(request, response);
                    
                

                }
            }
           
         
        } catch (FileUploadException ex) {  
            throw new ServletException(ex);
        } catch (Exception ex) {
            throw new ServletException(ex);
        }     
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(ProfileImage1.class.getName()).log(Level.SEVERE, null, ex);
         } catch (SQLException ex) {
             Logger.getLogger(ProfileImage1.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(ProfileImage1.class.getName()).log(Level.SEVERE, null, ex);
         } catch (SQLException ex) {
             Logger.getLogger(ProfileImage1.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
