/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package social;

import com.util.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;  
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Pratiksha
 */
public class LoginServlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String username=request.getParameter("username");
        String password=request.getParameter("password");  
        String email="";
        try {
            Connection con=DbConnection.getfcConection();
            PreparedStatement ps=con.prepareStatement("select * from user where username=? and password=?");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs=ps.executeQuery();
            
            HttpSession ss=request.getSession();  
            if(ss!=null){
            if(rs.next()){
                int id=rs.getInt(1);
            String firstname=rs.getString(2);
            String mobileno= rs.getString(6);
            ss.setAttribute("mobileno", mobileno);
           Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/sns", "root", "root");
            PreparedStatement ps1=con1.prepareStatement("update globalidlist set flag=1 where sns='facebook' and mobileno=?");
            ps1.setString(1, mobileno);      
            ps1.executeUpdate(); 
            email=rs.getString(7);
            
                    ss.setAttribute("email", email);
                    ss.setAttribute("id",id);
                    ss.setAttribute("firstname",firstname);  
                    ss.setAttribute("username", username);
                    ss.setAttribute("c1", "Welcome");
                    request.setAttribute("ii", 1);
                    PreparedStatement stmt=con.prepareStatement("update user set flag=1 where username=?");
                    stmt.setString(1,username);
                    int i=stmt.executeUpdate();
                    if(i>0){
                    
                    RequestDispatcher rd = request.getRequestDispatcher("Home.jsp");
                   rd.forward(request, response);}
            }else{
            ss.setAttribute("L1", "invalid username or password");
                    RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                    rd.include(request, response);
            }
            }
            else
            {
                ss.setAttribute("L1", "log in first");
                  RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                    rd.include(request, response);
            }
            
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
