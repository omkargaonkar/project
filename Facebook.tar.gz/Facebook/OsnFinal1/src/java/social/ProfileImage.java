/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package social;

import com.util.DbConnection;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileUploadException;

/**
 *
 * @author Sabari
 */
public class ProfileImage extends HttpServlet {
    private File tmpDir;
    private static final String DESTINATION_DIR_PATH = "file";
    private File destinationDir;
private static final long serialVersionUID = 1L;

    private static final String DATA_DIRECTORY = "data";
    private static final int MAX_MEMORY_SIZE = 1024 * 1024 * 2;
    private static final int MAX_REQUEST_SIZE = 1024 * 1024;
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
         System.out.print("checking innnnnnn");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            // Check that we have a file upload request
        boolean isMultipart = org.apache.commons.fileupload.servlet.ServletFileUpload.isMultipartContent(request);

        if (!isMultipart) {
            return;
        }
        HttpSession ss=request.getSession();
        String userid=ss.getAttribute("id").toString();   
          Connection con=DbConnection.getfcConection();
        // Create a factory for disk-based file items
        org.apache.commons.fileupload.disk.DiskFileItemFactory factory = new org.apache.commons.fileupload.disk.DiskFileItemFactory();

        // Sets the size threshold beyond which files are written directly to
        // disk.
        factory.setSizeThreshold(MAX_MEMORY_SIZE);

        // Sets the directory used to temporarily store files that are larger
        // than the configured size threshold. We use temporary directory for
        // java
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        // constructs the folder where uploaded file will be stored
        String uploadFolder = getServletContext().getRealPath("");
             //  + File.separator + DATA_DIRECTORY;         
        // Create a new file upload handler
        org.apache.commons.fileupload.servlet.ServletFileUpload upload = new org.apache.commons.fileupload.servlet.ServletFileUpload(factory);
            System.out.println("skhgksjhgkjshgkhksgks"+upload);
        // Set overall request size constraint
        upload.setSizeMax(MAX_REQUEST_SIZE);

        try {  
            // Parse the request
            List items = upload.parseRequest( request);     
            Iterator iter = items.iterator();
            while (iter.hasNext()) {
                org.apache.commons.fileupload.FileItem item = (org.apache.commons.fileupload.FileItem) iter.next();   

                if (!item.isFormField()) {
                    
                    
           
           
            
                    String fileName = new File(item.getName()).getName();
                    
                    String filePath = uploadFolder +"/userimages/"+ fileName;   
                    PreparedStatement ps2=con.prepareStatement("delete from userimages where userid=?");
                    ps2.setString(1, userid);
                    int j=ps2.executeUpdate();
                    if(j>0){
                     PreparedStatement ps=con.prepareStatement("insert into userimages values(?,?,?)");
            ps.setInt(1, 0);
            ps.setString(2,userid );
            ps.setString(3, fileName);
                    int i=ps.executeUpdate();
                    if(i>0){
                    File uploadedFile = new File(filePath); 
                    System.out.println(filePath);
                    // saves the file to upload directory
                    item.write(uploadedFile);}   
                }else{
                     PreparedStatement ps=con.prepareStatement("insert into userimages values(?,?,?)");
            ps.setInt(1, 0);
            ps.setString(2,userid );
            ps.setString(3, fileName);
                    int i=ps.executeUpdate();
                    if(i>0){
                    File uploadedFile = new File(filePath); 
                    System.out.println(filePath);
                    // saves the file to upload directory
                    item.write(uploadedFile);}
                    
                    
                    }
                    
                
                
                }
            }

            // displays done.jsp page after upload finished
            getServletContext().getRequestDispatcher("/Home.jsp").forward(
                    request, response);

        } catch (FileUploadException ex) {  
            throw new ServletException(ex);
        } catch (Exception ex) {
            throw new ServletException(ex);
        }     
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProfileImage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProfileImage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProfileImage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProfileImage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
