/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package social;

import com.util.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author admin
 */
public class Unblock extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            HttpSession ss=request.getSession();
            String username=ss.getAttribute("email").toString();
           
            
            String firstname=ss.getAttribute("firstname").toString();
            String fromuser=request.getParameter("friendname");
              Connection con=DbConnection.getfcConection();
            PreparedStatement ps1=con.prepareStatement("select * from user where emailid=?");              
            ps1.setString(1,username);
            ResultSet rs=ps1.executeQuery();
            int id1 = 0,id2 = 0;
            if(rs.next()){
            id1=rs.getInt(1);
            }
            PreparedStatement ps2=con.prepareStatement("select * from user where emailid=?");
            ps2.setString(1, fromuser);
            ResultSet rs2=ps2.executeQuery();
            if(rs2.next()){
            id2=rs2.getInt(1);      
            }
            PreparedStatement ps3=con.prepareStatement("insert into friends values(?,?,?)");        
            ps3.setInt(1, 0);
            ps3.setInt(2, id1);    
            ps3.setInt(3, id2); 
            int i2=ps3.executeUpdate();
            if(i2>0){
                PreparedStatement ps5=con.prepareStatement("insert into friends values(?,?,?)");
                ps5.setInt(1,0);
                ps5.setInt(2, id2);
                ps5.setInt(3, id1);
                ps5.executeUpdate();
                PreparedStatement ps4=con.prepareStatement("delete from blocklist where blockuser=? and byuser=?");
                ps4.setString(1, fromuser);
                ps4.setInt(2, id1);
                int i3=ps4.executeUpdate();
                
                 PreparedStatement ps6=con.prepareStatement("delete from block where ((userid=? and friendid=?) or (friendid=? and userid=?))");
                ps6.setInt(1, id2);
                ps6.setInt(2, id1);
                    ps6.setInt(3, id2);
                ps6.setInt(4, id1);
                ps6.executeUpdate();
                
                if(i3>0){
               response.sendRedirect("Home.jsp");
              }
                
            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Unblock.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Unblock.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Unblock.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Unblock.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
