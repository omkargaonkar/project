/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.util.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;       
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author $h@@n
 */
public class AcceptFriend extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        try {
            Connection con=DbConnection.getfcConection();
            Statement stmt = con.createStatement();
            Statement stmt1 = con.createStatement();
            Statement stmt2 = con.createStatement();
            Statement stmt3 = con.createStatement(); 
            Statement stmt4 = con.createStatement();
            String uname = (String) (session.getAttribute("uname"));
            String fromuser = request.getParameter("choice");
            String group = request.getParameter("group");
            String relation = request.getParameter("relation");
            String group1[] = request.getParameterValues("group1");
            String relation1 = request.getParameter("relation1");
            
            ResultSet rs = stmt.executeQuery("select friends,family,friend from users where username='" + uname + "'");
            if (rs.next()) {
                String frnd2 = rs.getString(1);
                frnd2 = frnd2 + ", " + fromuser;
                if (relation1.equals("family")) {
                    String fmember1 = rs.getString(2);
                    fmember1 = fmember1 + ", " + fromuser;
                    stmt3.executeUpdate("update users set family='" + fmember1 + "' where username='" + uname + "'");
                } else {
                    String frmember1 = rs.getString(3);
                    frmember1 = frmember1 + ", " + fromuser;
                    stmt3.executeUpdate("update users set friend='" + frmember1 + "' where username='" + uname + "'");
                }
                stmt4.executeUpdate("update users set friends='" + frnd2 + "' where username='" + uname + "'");
            }
                
                
  /*          for (int j = 0; j < group1.length; j++) {
                    String r = group1[j];
                    ResultSet rs2 = stmt1.executeQuery("select members from groups where owner='" + uname + "' and name='" + r + "'");
                    String member ="";
                    if (rs2.next()) {
                        member = rs2.getString(1);
                        member = member + "," + fromuser;
                    }
                    stmt2.executeUpdate("update groups set members='" + member + "' where name='" + r + "' and owner='" + uname + "'");
                }
    */        ResultSet rs1 = stmt2.executeQuery("select friends,family,friend from users where username='" + fromuser + "'");
            if (rs1.next()) {
                String frnd1 = rs1.getString(1);
                frnd1 = frnd1 + ", " + uname;
                if (relation.equals("family")) {
                    String fmember = rs1.getString(2);
                    fmember = fmember + ", " + uname;
                    stmt1.executeUpdate("update users set family='" + fmember + "' where username='" + fromuser + "'");
                } else {
                    String frmember = rs1.getString(3);
                    frmember = frmember + ", " + uname;
                    stmt1.executeUpdate("update users set friend='" + frmember + "' where username='" + fromuser + "'");
                }
                stmt2.executeUpdate("update users set friends='" + frnd1 + "' where username='" + fromuser + "'");
                String q[] = group.split(",");
                String r="";
                for (int j = 0; j < q.length; j++) {
                    r = q[j];
                    r = r.trim();  
                } 
     /*               ResultSet rs2 = stmt3.executeQuery("select members from groups where owner='" + fromuser + "' and name='" + r + "'");
                    String trim="";
                    if (rs2.next()) {
                        String member = rs2.getString(1);
                        member = member + "," + uname;
                        trim = member.trim();
                    }
                    int qw=stmt4.executeUpdate("update groups set members='" + trim + "' where name='" + r + "' and owner='" + fromuser + "'");
                    if(qw>0){
                        out.print("sucessfull");
                        response.sendRedirect("FriendsRequest.jsp");
                    }   */
            }
           stmt.executeUpdate("DELETE FROM friendrequest WHERE fromuser='" + fromuser + "' and touser='" + uname + "';");
    response.sendRedirect("FriendsRequest.jsp");   
            }
        catch(SQLException s){
            out.print(s.getMessage());
        }catch (Exception e) {
            out.print(e);
        }
        finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}  
