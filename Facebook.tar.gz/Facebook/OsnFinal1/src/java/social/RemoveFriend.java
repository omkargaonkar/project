package social;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.util.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author $h@@n
 */
public class RemoveFriend extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();
        String remove=request.getParameter("remove");
       out.print(remove);
        try{
             Connection con=DbConnection.getfcConection();
            Statement stmt = con.createStatement();
             Statement stmt1 = con.createStatement();
              Statement stmt2 = con.createStatement();
            String uname = (String) (session.getAttribute("uname"));
            out.print(remove);
            ResultSet rs=stmt.executeQuery("select friends,family,friend from users where username='"+remove+"'");
            
            out.print(remove);
            ResultSet rs1=stmt1.executeQuery("select friends,family,friend from users where username='"+uname+"'");
           out.print(remove);
            if(rs.next())
            {
                String friends=rs.getString(1);
                String newfrnds=friends.replaceFirst(","+uname, "");
                String family=rs.getString(2);
                String newfmly=family.replaceFirst(","+uname, "");
                String friend=rs.getString(3);
                String newfrnd=friend.replaceFirst(","+uname, "");
                stmt2.executeUpdate("update users set family='" + newfmly + "',friends='"+newfrnds+"',friend='"+newfrnd+"' where username='" + uname + "'");
            }
             if(rs1.next())
            {
                String friends=rs1.getString(1);
                String newfrnds=friends.replaceFirst(","+remove, "");
                String family=rs1.getString(2);
                String newfmly=family.replaceFirst(","+remove, "");
                String friend=rs1.getString(3);
                String newfrnd=friend.replaceFirst(","+remove, "");
                stmt2.executeUpdate("update users set family='" + newfmly + "',friends='"+newfrnds+"',friend='"+newfrnd+"' where username='" + remove + "'");
            }
        }catch(Exception e)
        {
            out.print(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
