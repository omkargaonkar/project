/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.util;

import au.com.bytecode.opencsv.CSVReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

    public class AnsTest {

  public static void main(String[] args) throws UnknownHostException, SQLException, FileNotFoundException, IOException, ClassNotFoundException {
	// String startFile="C:\\Users\\accede\\Desktop\\a.txt";
	        // print the IP Address of your machine (inside your local network)
	       // System.out.println(InetAddress.getLocalHost().getHostAddress());
	 
	        // print the IP Address of a web site
	      //  System.out.println(InetAddress.getByName("www.javacodegeeks.com"));
	 
	        // print all the IP Addresses that are assigned to a certain domain
   // File f=new File(startFile);
            ArrayList<String> line = new ArrayList<String>();
   //         Scanner sa=new Scanner(f);
    //        while(sa.hasNextLine()){
   //         String sss=sa.nextLine().trim();
     //       line.add(sss);
     //       }
            
            
      String d="www.google.co.in";
      //for(String ss:line){
     // d=ss;
    
      
	        InetAddress[] inetAddresses = InetAddress.getAllByName(d);
	 String z="";
	        for (InetAddress ipAddress : inetAddresses) {
                    
	            System.out.println(ipAddress);
                    String a=ipAddress.toString();
                    String[] b=a.split("/");
                    for(String s:b){
                      int i= b.length;
                      z=b[i-1];
                    }
                    Connection connection=DbConnection.getfcConection();
                    PreparedStatement ps=connection.prepareStatement("insert into domaindetails (donainName,isSSLVerified,ipaddress) values(?,?,?)");
                    //ps.setInt(1, 1);
                    ps.setString(1,d);
                    ps.setInt(2, 1);
                    ps.setString(3, z);
                    ps.executeUpdate();
	        }
	    }
  //}
    }